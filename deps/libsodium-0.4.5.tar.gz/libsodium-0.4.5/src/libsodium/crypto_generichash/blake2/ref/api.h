
#include "crypto_generichash_blake2b.h"

#define crypto_generichash_blake2b crypto_generichash_blake2b_ref
